# Ablage für nicht aktive Termine ✔️
* wird nur nach login gerendert
* wird in der desktop Ansicht als klappbare Sidebar gelöst
* wird in der mobilen Ansicht unter der Liste angezeigt 

# Upload eines Logos in den Header (✔️)
* fügt die Möglichkeit hinzu eine Logo-Datei hochzuladen
* _UPDATE: wird nicht umgesetzt, da das Tool in der Regel auf der Website der Organisation eingebunden ist._
* dieses Logo wird auch als favicon genutzt
* _UPDATE: Es wird immer das WeekWise favicon genutzt._

# Hinzufügen der Option 'location' ✔️


# Entfernen der debugg Befehle


# Entfernen der googlefonts ✔️
* wird durch freie vectorgrafiken ersetzt, die auf den Server geladen werden

# Update des Installers - lädt alle Dateien im ressource Ordner herunter (✔️)
* Nach Ideen schauen: Installationsdateien überprüfen, damit kein Schadcode eingeschmuggelt werden kann. 
* _UPDATE: installer so strukturiert, dass neue dateien einfach hinzugefügt werden können. Zip Archive werden geladen und entpackt. Alle Dateien laden ist nicht zielführend und unsicher_

# Code wird aufgesplittet und in mehrere Dateien aufgeteilt um übbersicht und Wartbarkeit zu verbessern. (✔️)
* insbesondere style.css anlegen